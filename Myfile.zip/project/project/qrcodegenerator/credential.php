<?php 
	/*Enter your API_KEY*/
	define("API_KEY", "b14c715c48aa15a473dcba8a9b67e6948d2f6b0be2e1371b796090f225437b1b");

	/*You can enter mobile number here*/
	define("MOBILE", '');
 ?>