<script>
var p1 = "success";
</script>

<?php
echo "<script>document.writeln(p1);</script>";
?>