<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="POST" action="one.php">
	<label for="name">Name: </label>
	<input type="text" name="name">
	<input type="submit">
</form>
</body>
</html>
